(function(){
var translateObjs = {};
function trans(a, b) {
    var c = arguments['length'] === 0x1 ? [arguments[0x0]] : Array['apply'](null, arguments);
    translateObjs[c[0x0]] = c;
    return '';
}
function regTextVar(a, b) {
    var c = ![];
    b = b['toLowerCase']();
    var d = function () {
        var m = this['get']('data');
        m['updateText'](m['translateObjs'][a]);
    };
    var e = function (m) {
        var n = m['data']['nextSelectedIndex'];
        if (n >= 0x0) {
            var o = m['source']['get']('items')[n];
            var p = function () {
                o['unbind']('start', p, this);
                d['call'](this);
            };
            o['bind']('start', p, this);
        } else
            d['call'](this);
    };
    var f = function (m) {
        return function (n) {
            if (m in n) {
                d['call'](this);
            }
        }['bind'](this);
    };
    var g = function (m, n) {
        return function (o, p) {
            if (m == o && n in p) {
                d['call'](this);
            }
        }['bind'](this);
    };
    var h = function (m, n, o) {
        for (var p = 0x0; p < m['length']; ++p) {
            var q = m[p];
            var r = q['get']('selectedIndex');
            if (r >= 0x0) {
                var s = n['split']('.');
                var t = q['get']('items')[r];
                if (o !== undefined && !o['call'](this, t))
                    continue;
                for (var u = 0x0; u < s['length']; ++u) {
                    if (t == undefined)
                        return '';
                    t = 'get' in t ? t['get'](s[u]) : t[s[u]];
                }
                return t;
            }
        }
        return '';
    };
    var i = function (m) {
        var n = m['get']('player');
        return n !== undefined && n['get']('viewerArea') == this['getMainViewer']();
    };
    switch (b) {
    case 'title':
    case 'subtitle':
        var k = function () {
            switch (b) {
            case 'title':
                return 'media.label';
            case 'subtitle':
                return 'media.data.subtitle';
            }
        }();
        if (k) {
            return function () {
                var m = this['_getPlayListsWithViewer'](this['getMainViewer']());
                if (!c) {
                    for (var n = 0x0; n < m['length']; ++n) {
                        m[n]['bind']('changing', e, this);
                    }
                    c = !![];
                }
                return h['call'](this, m, k, i);
            };
        }
        break;
    default:
        if (b['startsWith']('quiz.') && 'Quiz' in TDV) {
            var l = undefined;
            var k = function () {
                switch (b) {
                case 'quiz.questions.answered':
                    return TDV['Quiz']['PROPERTY']['QUESTIONS_ANSWERED'];
                case 'quiz.question.count':
                    return TDV['Quiz']['PROPERTY']['QUESTION_COUNT'];
                case 'quiz.items.found':
                    return TDV['Quiz']['PROPERTY']['ITEMS_FOUND'];
                case 'quiz.item.count':
                    return TDV['Quiz']['PROPERTY']['ITEM_COUNT'];
                case 'quiz.score':
                    return TDV['Quiz']['PROPERTY']['SCORE'];
                case 'quiz.score.total':
                    return TDV['Quiz']['PROPERTY']['TOTAL_SCORE'];
                case 'quiz.time.remaining':
                    return TDV['Quiz']['PROPERTY']['REMAINING_TIME'];
                case 'quiz.time.elapsed':
                    return TDV['Quiz']['PROPERTY']['ELAPSED_TIME'];
                case 'quiz.time.limit':
                    return TDV['Quiz']['PROPERTY']['TIME_LIMIT'];
                case 'quiz.media.items.found':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_ITEMS_FOUND'];
                case 'quiz.media.item.count':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_ITEM_COUNT'];
                case 'quiz.media.questions.answered':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_QUESTIONS_ANSWERED'];
                case 'quiz.media.question.count':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_QUESTION_COUNT'];
                case 'quiz.media.score':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_SCORE'];
                case 'quiz.media.score.total':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_TOTAL_SCORE'];
                case 'quiz.media.index':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_INDEX'];
                case 'quiz.media.count':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_COUNT'];
                case 'quiz.media.visited':
                    return TDV['Quiz']['PROPERTY']['PANORAMA_VISITED_COUNT'];
                default:
                    var m = /quiz\.([\w_]+)\.(.+)/['exec'](b);
                    if (m) {
                        l = m[0x1];
                        switch ('quiz.' + m[0x2]) {
                        case 'quiz.score':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['SCORE'];
                        case 'quiz.score.total':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['TOTAL_SCORE'];
                        case 'quiz.media.items.found':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_ITEMS_FOUND'];
                        case 'quiz.media.item.count':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_ITEM_COUNT'];
                        case 'quiz.media.questions.answered':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_QUESTIONS_ANSWERED'];
                        case 'quiz.media.question.count':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_QUESTION_COUNT'];
                        case 'quiz.questions.answered':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['QUESTIONS_ANSWERED'];
                        case 'quiz.question.count':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['QUESTION_COUNT'];
                        case 'quiz.items.found':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['ITEMS_FOUND'];
                        case 'quiz.item.count':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['ITEM_COUNT'];
                        case 'quiz.media.score':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_SCORE'];
                        case 'quiz.media.score.total':
                            return TDV['Quiz']['OBJECTIVE_PROPERTY']['PANORAMA_TOTAL_SCORE'];
                        }
                    }
                }
            }();
            if (k) {
                return function () {
                    var m = this['get']('data')['quiz'];
                    if (m) {
                        if (!c) {
                            if (l != undefined)
                                if (l == 'global') {
                                    var o = this['get']('data')['quizConfig'];
                                    var q = o['objectives'];
                                    for (var s = 0x0, u = q['length']; s < u; ++s) {
                                        m['bind'](TDV['Quiz']['EVENT_OBJECTIVE_PROPERTIES_CHANGE'], g['call'](this, q[s]['id'], k), this);
                                    }
                                } else {
                                    m['bind'](TDV['Quiz']['EVENT_OBJECTIVE_PROPERTIES_CHANGE'], g['call'](this, l, k), this);
                                }
                            else
                                m['bind'](TDV['Quiz']['EVENT_PROPERTIES_CHANGE'], f['call'](this, k), this);
                            c = !![];
                        }
                        try {
                            var v = 0x0;
                            if (l != undefined) {
                                if (l == 'global') {
                                    var o = this['get']('data')['quizConfig'];
                                    var q = o['objectives'];
                                    for (var s = 0x0, u = q['length']; s < u; ++s) {
                                        v += m['getObjective'](q[s]['id'], k);
                                    }
                                } else {
                                    v = m['getObjective'](l, k);
                                }
                            } else {
                                v = m['get'](k);
                                if (k == TDV['Quiz']['PROPERTY']['PANORAMA_INDEX'])
                                    v += 0x1;
                            }
                            return v;
                        } catch (w) {
                            return undefined;
                        }
                    }
                };
            }
        }
        break;
    }
    return '';
}
function createQuizConfig(player, a) {
    var b = {};
    b['player'] = player;
    b['playList'] = a;
    function c(f) {
        for (var g = 0x0; g < f['length']; ++g) {
            var h = f[g];
            if ('id' in h)
                player[h['id']] = h;
        }
    }
    if (b['questions']) {
        c(b['questions']);
        for (var d = 0x0; d < b['questions']['length']; ++d) {
            var e = b['questions'][d];
            c(e['options']);
        }
    }
    if (b['objectives']) {
        c(b['objectives']);
    }
    if (b['califications']) {
        c(b['califications']);
    }
    if (b['score']) {
        player[b['score']['id']] = b['score'];
    }
    if (b['question']) {
        player[b['question']['id']] = b['question'];
    }
    if (b['timeout']) {
        player[b['timeout']['id']] = b['timeout'];
    }
    player['get']('data')['translateObjs'] = translateObjs;
    return b;
}
var script = {"scrollBarColor":"#000000","propagateClick":false,"start":"this.init()","paddingLeft":0,"backgroundOpacity":1,"defaultVRPointer":"laser","class":"Player","paddingRight":0,"vrPolyfillScale":0.75,"mobileMipmappingEnabled":false,"mediaActivationMode":"window","definitions": [{"overlays":["this.overlay_8748B083_9464_00B5_41D4_8F34F849D000"],"partial":false,"thumbnailUrl":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_t.jpg","hfovMin":"135%","class":"Panorama","id":"panorama_8748A083_9464_00B5_41D2_A96137571B7D","adjacentPanoramas":[{"backwardYaw":-130.86,"yaw":99.86,"select":"this.overlay_8748B083_9464_00B5_41D4_8F34F849D000.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_8748B083_9464_00B5_41D4_8F34F849D000"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC"}],"pitch":0,"vfov":180,"label":trans('panorama_8748A083_9464_00B5_41D2_A96137571B7D.label'),"hfovMax":130,"frames":[{"class":"CubicPanoramaFrame","cube":{"class":"ImageResource","levels":[{"colCount":18,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":3,"url":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_0/{face}/0/{row}_{column}.jpg"},{"colCount":12,"height":1024,"width":6144,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":2,"url":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_0/{face}/1/{row}_{column}.jpg"},{"colCount":6,"height":512,"width":3072,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"rowCount":1,"url":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_0/{face}/2/{row}_{column}.jpg"},{"colCount":6,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"mobilevr","rowCount":1,"url":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_0/{face}/vr/0.jpg"}]},"thumbnailUrl":"media/panorama_8748A083_9464_00B5_41D2_A96137571B7D_t.jpg"}],"hfov":360,"data":{"label":"08"}},{"initialPosition":{"class":"PanoramaCameraPosition","yaw":0,"pitch":0},"hoverFactor":0,"automaticZoomSpeed":10,"initialSequence":"this.sequence_99DCD761_939C_0075_41CA_47608062B8BE","class":"PanoramaCamera","id":"panorama_87579F10_9464_01D3_41B7_84AC383AF654_camera"},{"initialPosition":{"class":"PanoramaCameraPosition","yaw":0,"pitch":0},"hoverFactor":0,"automaticZoomSpeed":10,"initialSequence":"this.sequence_99DC2762_939C_0077_41DB_4F26E05FD433","class":"PanoramaCamera","id":"panorama_8748A083_9464_00B5_41D2_A96137571B7D_camera"},{"initialPosition":{"class":"PanoramaCameraPosition","yaw":0,"pitch":0},"hoverFactor":0,"automaticZoomSpeed":10,"initialSequence":"this.sequence_99A0375F_939C_004D_4196_631F87459AB8","class":"PanoramaCamera","id":"panorama_87F41D6F_9464_004D_41D9_AFB00610D952_camera"},{"overlays":["this.overlay_87495C00_9464_07B3_41DA_BA543F102B26","this.overlay_87494C00_9464_07B3_41CF_1B7EA8E66D14"],"partial":false,"thumbnailUrl":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_t.jpg","hfovMin":"135%","class":"Panorama","id":"panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC","adjacentPanoramas":[{"backwardYaw":-124.43,"yaw":49.12,"select":"this.overlay_87495C00_9464_07B3_41DA_BA543F102B26.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_87495C00_9464_07B3_41DA_BA543F102B26"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_87F41D6F_9464_004D_41D9_AFB00610D952"},{"backwardYaw":99.86,"yaw":-130.86,"select":"this.overlay_87494C00_9464_07B3_41CF_1B7EA8E66D14.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_87494C00_9464_07B3_41CF_1B7EA8E66D14"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_8748A083_9464_00B5_41D2_A96137571B7D"}],"pitch":0,"vfov":180,"label":trans('panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC.label'),"hfovMax":130,"frames":[{"class":"CubicPanoramaFrame","cube":{"class":"ImageResource","levels":[{"colCount":18,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":3,"url":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_0/{face}/0/{row}_{column}.jpg"},{"colCount":12,"height":1024,"width":6144,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":2,"url":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_0/{face}/1/{row}_{column}.jpg"},{"colCount":6,"height":512,"width":3072,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"rowCount":1,"url":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_0/{face}/2/{row}_{column}.jpg"},{"colCount":6,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"mobilevr","rowCount":1,"url":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_0/{face}/vr/0.jpg"}]},"thumbnailUrl":"media/panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_t.jpg"}],"hfov":360,"data":{"label":"07"}},{"overlays":["this.overlay_87566F10_9464_01D3_41D6_9A1583AED5F3"],"partial":false,"thumbnailUrl":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_t.jpg","hfovMin":"135%","class":"Panorama","id":"panorama_87579F10_9464_01D3_41B7_84AC383AF654","adjacentPanoramas":[{"backwardYaw":-170.66,"yaw":7.16,"select":"this.overlay_87566F10_9464_01D3_41D6_9A1583AED5F3.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_87566F10_9464_01D3_41D6_9A1583AED5F3"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_87F41D6F_9464_004D_41D9_AFB00610D952"}],"pitch":0,"vfov":180,"label":trans('panorama_87579F10_9464_01D3_41B7_84AC383AF654.label'),"hfovMax":130,"frames":[{"class":"CubicPanoramaFrame","cube":{"class":"ImageResource","levels":[{"colCount":18,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":3,"url":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_0/{face}/0/{row}_{column}.jpg"},{"colCount":12,"height":1024,"width":6144,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":2,"url":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_0/{face}/1/{row}_{column}.jpg"},{"colCount":6,"height":512,"width":3072,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"rowCount":1,"url":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_0/{face}/2/{row}_{column}.jpg"},{"colCount":6,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"mobilevr","rowCount":1,"url":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_0/{face}/vr/0.jpg"}]},"thumbnailUrl":"media/panorama_87579F10_9464_01D3_41B7_84AC383AF654_t.jpg"}],"hfov":360,"data":{"label":"06"}},{"toolTipBorderSize":1,"height":"100%","playbackBarHeadBackgroundColorDirection":"vertical","paddingLeft":0,"progressBarOpacity":1,"playbackBarProgressBorderSize":0,"toolTipPaddingTop":4,"toolTipPaddingLeft":6,"progressBottom":0,"vrPointerSelectionColor":"#FF6600","paddingRight":0,"transitionDuration":500,"playbackBarHeadWidth":6,"subtitlesTop":0,"playbackBarBackgroundColorDirection":"vertical","toolTipShadowColor":"#333138","toolTipFontColor":"#606060","playbackBarRight":0,"playbackBarHeadShadowBlurRadius":3,"progressHeight":10,"subtitlesTextDecoration":"none","progressBorderSize":0,"progressBackgroundColorRatios":[0],"subtitlesBorderSize":0,"playbackBarProgressBorderRadius":0,"progressBarBorderRadius":0,"subtitlesTextShadowOpacity":1,"playbackBarProgressBackgroundColor":["#3399FF"],"toolTipBackgroundColor":"#F6F6F6","vrPointerSelectionTime":2000,"playbackBarLeft":0,"vrPointerColor":"#FFFFFF","surfaceReticleColor":"#FFFFFF","playbackBarHeadHeight":15,"toolTipPaddingRight":6,"playbackBarHeadShadowColor":"#000000","playbackBarHeadShadowOpacity":0.7,"progressBarBorderSize":0,"toolTipHorizontalAlign":"center","playbackBarHeadBackgroundColorRatios":[0,1],"surfaceReticleOpacity":0.6,"subtitlesTextShadowBlurRadius":0,"subtitlesFontColor":"#FFFFFF","subtitlesTextShadowColor":"#000000","progressRight":0,"playbackBarHeadShadowVerticalLength":0,"progressOpacity":1,"minHeight":50,"toolTipShadowHorizontalLength":0,"paddingBottom":0,"minWidth":100,"subtitlesFontFamily":"Arial","toolTipShadowBlurRadius":3,"paddingTop":0,"subtitlesTextShadowVerticalLength":1,"playbackBarHeadBorderSize":0,"toolTipOpacity":1,"subtitlesFontSize":"3vmin","displayTooltipInTouchScreens":true,"playbackBarProgressBackgroundColorRatios":[0],"toolTipPaddingBottom":4,"progressBarBackgroundColorDirection":"vertical","progressBarBorderColor":"#000000","progressBorderRadius":0,"toolTipTextShadowBlurRadius":3,"subtitlesPaddingTop":5,"toolTipDisplayTime":600,"playbackBarBorderRadius":0,"subtitlesShadow":false,"playbackBarBorderColor":"#FFFFFF","borderRadius":0,"progressBarBackgroundColorRatios":[0],"subtitlesFontWeight":"normal","playbackBarProgressBorderColor":"#000000","propagateClick":false,"playbackBarHeadOpacity":1,"progressLeft":0,"toolTipBorderColor":"#767676","toolTipFontSize":"1.11vmin","progressBackgroundColorDirection":"vertical","playbackBarBackgroundOpacity":1,"class":"ViewerArea","subtitlesOpacity":1,"toolTipBorderRadius":3,"playbackBarHeadBackgroundColor":["#111111","#666666"],"playbackBarHeadShadow":true,"playbackBarOpacity":1,"transitionMode":"blending","toolTipTextShadowColor":"#000000","subtitlesBackgroundColor":"#000000","surfaceReticleSelectionColor":"#FFFFFF","toolTipShadowSpread":0,"subtitlesBackgroundOpacity":0.2,"subtitlesGap":0,"progressBackgroundOpacity":1,"playbackBarHeadBorderRadius":0,"playbackBarHeadShadowHorizontalLength":0,"displayTooltipInSurfaceSelection":true,"subtitlesPaddingBottom":5,"playbackBarProgressOpacity":1,"toolTipFontWeight":"normal","firstTransitionDuration":0,"subtitlesHorizontalAlign":"center","width":"100%","toolTipFontFamily":"Arial","playbackBarHeadBorderColor":"#000000","playbackBarBottom":5,"progressBorderColor":"#000000","subtitlesPaddingLeft":5,"doubleClickAction":"toggle_fullscreen","subtitlesTextShadowHorizontalLength":1,"toolTipShadowVerticalLength":0,"toolTipFontStyle":"normal","surfaceReticleSelectionOpacity":1,"progressBarBackgroundColor":["#3399FF"],"playbackBarBorderSize":0,"subtitlesVerticalAlign":"bottom","id":"MainViewer","toolTipShadowOpacity":1,"subtitlesEnabled":true,"playbackBarProgressBackgroundColorDirection":"vertical","subtitlesPaddingRight":5,"borderSize":0,"progressBackgroundColor":["#FFFFFF"],"playbackBarBackgroundColor":["#FFFFFF"],"subtitlesBottom":50,"shadow":false,"toolTipTextShadowOpacity":0,"translationTransitionDuration":1000,"playbackBarHeight":10,"data":{"name":"Main Viewer"},"subtitlesBorderColor":"#FFFFFF"},{"overlays":["this.overlay_87F44D70_9464_0054_41D8_318CB76C11F6","this.overlay_87F4BD71_9464_0055_41E1_31BABDF0FE2F"],"partial":false,"thumbnailUrl":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_t.png","hfovMin":"135%","id":"panorama_87F41D6F_9464_004D_41D9_AFB00610D952","adjacentPanoramas":[{"backwardYaw":49.12,"yaw":-124.43,"select":"this.overlay_87F44D70_9464_0054_41D8_318CB76C11F6.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_87F44D70_9464_0054_41D8_318CB76C11F6"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC"},{"backwardYaw":7.16,"yaw":-170.66,"select":"this.overlay_87F4BD71_9464_0055_41E1_31BABDF0FE2F.get('areas').forEach(function(a){ a.trigger('click') })","data":{"overlayID":"overlay_87F4BD71_9464_0055_41E1_31BABDF0FE2F"},"class":"AdjacentPanorama","distance":100,"panorama":"this.panorama_87579F10_9464_01D3_41B7_84AC383AF654"}],"pitch":0,"class":"Panorama","vfov":180,"label":trans('panorama_87F41D6F_9464_004D_41D9_AFB00610D952.label'),"hfovMax":130,"frames":[{"class":"CubicPanoramaFrame","cube":{"class":"ImageResource","levels":[{"colCount":18,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":3,"url":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_0/{face}/0/{row}_{column}.jpg"},{"colCount":12,"height":1024,"width":6144,"class":"TiledImageResourceLevel","tags":"ondemand","rowCount":2,"url":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_0/{face}/1/{row}_{column}.jpg"},{"colCount":6,"height":512,"width":3072,"class":"TiledImageResourceLevel","tags":["ondemand","preload"],"rowCount":1,"url":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_0/{face}/2/{row}_{column}.jpg"},{"colCount":6,"height":1536,"width":9216,"class":"TiledImageResourceLevel","tags":"mobilevr","rowCount":1,"url":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_0/{face}/vr/0.jpg"}]},"thumbnailUrl":"media/panorama_87F41D6F_9464_004D_41D9_AFB00610D952_t.jpg"}],"hfov":360,"data":{"label":"05"}},{"initialPosition":{"class":"PanoramaCameraPosition","yaw":0,"pitch":0},"hoverFactor":0,"automaticZoomSpeed":10,"initialSequence":"this.sequence_99DC0761_939C_0074_4198_2C0ACC8F93AF","class":"PanoramaCamera","id":"panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_camera"},{"zoomEnabled":true,"viewerArea":"this.MainViewer","mouseControlMode":"drag_rotation","surfaceSelectionEnabled":false,"gyroscopeVerticalDraggingEnabled":true,"aaEnabled":true,"touchControlMode":"drag_rotation","class":"PanoramaPlayer","id":"MainViewerPanoramaPlayer","displayPlaybackBar":true,"arrowKeysAction":"translate"},{"class":"PlayList","id":"mainPlayList","items":[{"media":"this.panorama_87F41D6F_9464_004D_41D9_AFB00610D952","camera":"this.panorama_87F41D6F_9464_004D_41D9_AFB00610D952_camera","begin":"this.setEndToItemIndex(this.mainPlayList, 0, 1)","class":"PanoramaPlayListItem","player":"this.MainViewerPanoramaPlayer"},{"media":"this.panorama_87579F10_9464_01D3_41B7_84AC383AF654","camera":"this.panorama_87579F10_9464_01D3_41B7_84AC383AF654_camera","begin":"this.setEndToItemIndex(this.mainPlayList, 1, 2)","class":"PanoramaPlayListItem","player":"this.MainViewerPanoramaPlayer"},{"media":"this.panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC","camera":"this.panorama_87492C00_9464_07B3_41DA_7CB6AFE32CEC_camera","begin":"this.setEndToItemIndex(this.mainPlayList, 2, 3)","class":"PanoramaPlayListItem","player":"this.MainViewerPanoramaPlayer"},{"media":"this.panorama_8748A083_9464_00B5_41D2_A96137571B7D","camera":"this.panorama_8748A083_9464_00B5_41D2_A96137571B7D_camera","begin":"this.setEndToItemIndex(this.mainPlayList, 3, 0)","class":"PanoramaPlayListItem","player":"this.MainViewerPanoramaPlayer","end":"this.trigger('tourEnded')"}]},{"areas":["this.HotspotPanoramaOverlayArea_9C7C825F_93BC_004D_41D7_13C389EB59F4"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_8748B083_9464_00B5_41D4_8F34F849D000","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":99.86,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AFAE05_946C_03BD_41D0_2AF949C022C8","scaleMode":"fit_inside","pitch":1.08}]},{"movements":[{"class":"DistancePanoramaCameraMovement","easing":"cubic_in","yawDelta":18.5,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"linear","yawDelta":323,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"cubic_out","yawDelta":18.5,"yawSpeed":7.96}],"class":"PanoramaCameraSequence","id":"sequence_99DCD761_939C_0075_41CA_47608062B8BE","restartMovementOnUserInteraction":false},{"movements":[{"class":"DistancePanoramaCameraMovement","easing":"cubic_in","yawDelta":18.5,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"linear","yawDelta":323,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"cubic_out","yawDelta":18.5,"yawSpeed":7.96}],"class":"PanoramaCameraSequence","id":"sequence_99DC2762_939C_0077_41DB_4F26E05FD433","restartMovementOnUserInteraction":false},{"movements":[{"class":"DistancePanoramaCameraMovement","easing":"cubic_in","yawDelta":18.5,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"linear","yawDelta":323,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"cubic_out","yawDelta":18.5,"yawSpeed":7.96}],"class":"PanoramaCameraSequence","id":"sequence_99A0375F_939C_004D_4196_631F87459AB8","restartMovementOnUserInteraction":false},{"areas":["this.HotspotPanoramaOverlayArea_9C73244F_93A4_004D_41C5_FC89A1AA32D1"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_87495C00_9464_07B3_41DA_BA543F102B26","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":49.12,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AF3E05_946C_03BD_41D9_959FFD020AC8","scaleMode":"fit_inside","pitch":6.27}]},{"areas":["this.HotspotPanoramaOverlayArea_9C5DA04A_93BC_3FB7_41D8_044C98A4ECEF"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_87494C00_9464_07B3_41CF_1B7EA8E66D14","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":-130.86,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AF6E05_946C_03BD_41C2_5EF4C77A2321","scaleMode":"fit_inside","pitch":7.26}]},{"areas":["this.HotspotPanoramaOverlayArea_83B34E76_93BC_005F_41C5_16A1B87E22F5"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_87566F10_9464_01D3_41D6_9A1583AED5F3","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":7.16,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AEFE04_946C_03B3_41B2_3C5F3B41A28D","scaleMode":"fit_inside","pitch":4.65}]},{"areas":["this.HotspotPanoramaOverlayArea_9C94AD87_93A4_00BD_41B2_F703747BBA31"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_87F44D70_9464_0054_41D8_318CB76C11F6","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":-124.43,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AE9E04_946C_03B3_41B3_8EF014D0EA47","scaleMode":"fit_inside","pitch":0.88}]},{"areas":["this.HotspotPanoramaOverlayArea_83CD85A1_93BC_00F5_41DE_08963B400DED"],"enabledInCardboard":true,"maps":[],"data":{"label":"Circle Generic 03"},"useHandCursor":true,"class":"HotspotPanoramaOverlay","id":"overlay_87F4BD71_9464_0055_41E1_31BABDF0FE2F","items":[{"class":"HotspotPanoramaOverlayImage","distance":100,"yaw":-170.66,"vfov":10.5,"verticalAlign":"middle","horizontalAlign":"center","data":{"label":"Circle Generic 03"},"hfov":10.5,"image":"this.AnimatedImageResource_84AEBE04_946C_03B3_41B5_6C96AEEC0152","scaleMode":"fit_inside","pitch":3.87}]},{"movements":[{"class":"DistancePanoramaCameraMovement","easing":"cubic_in","yawDelta":18.5,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"linear","yawDelta":323,"yawSpeed":7.96},{"class":"DistancePanoramaCameraMovement","easing":"cubic_out","yawDelta":18.5,"yawSpeed":7.96}],"class":"PanoramaCameraSequence","id":"sequence_99DC0761_939C_0074_4198_2C0ACC8F93AF","restartMovementOnUserInteraction":false},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_9C7C825F_93BC_004D_41D7_13C389EB59F4","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 2)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AFAE05_946C_03BD_41D0_2AF949C022C8","frameDuration":41,"colCount":24},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_9C73244F_93A4_004D_41C5_FC89A1AA32D1","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 0)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AF3E05_946C_03BD_41D9_959FFD020AC8","frameDuration":41,"colCount":24},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_9C5DA04A_93BC_3FB7_41D8_044C98A4ECEF","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 3)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AF6E05_946C_03BD_41C2_5EF4C77A2321","frameDuration":41,"colCount":24},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_83B34E76_93BC_005F_41C5_16A1B87E22F5","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 0)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AEFE04_946C_03B3_41B2_3C5F3B41A28D","frameDuration":41,"colCount":24},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_9C94AD87_93A4_00BD_41B2_F703747BBA31","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 2)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AE9E04_946C_03B3_41B3_8EF014D0EA47","frameDuration":41,"colCount":24},{"class":"HotspotPanoramaOverlayArea","id":"HotspotPanoramaOverlayArea_83CD85A1_93BC_00F5_41DE_08963B400DED","mapColor":"any","click":"this.mainPlayList.set('selectedIndex', 1)"},{"frameCount":24,"rowCount":1,"levels":[{"class":"ImageResourceLevel","url":"media/res_830FB837_93BC_0FDD_41C9_F9510CF9BE1A_0.png","height":165,"width":3960}],"class":"AnimatedImageResource","id":"AnimatedImageResource_84AEBE04_946C_03B3_41B5_6C96AEEC0152","frameDuration":41,"colCount":24}],"scrollBarMargin":2,"desktopMipmappingEnabled":false,"scripts":{"visibleComponentsIfPlayerFlagEnabled":TDV.Tour.Script.visibleComponentsIfPlayerFlagEnabled,"sendAnalyticsData":TDV.Tour.Script.sendAnalyticsData,"historyGoForward":TDV.Tour.Script.historyGoForward,"htmlToPlainText":TDV.Tour.Script.htmlToPlainText,"historyGoBack":TDV.Tour.Script.historyGoBack,"copyToClipboard":TDV.Tour.Script.copyToClipboard,"updateVideoCues":TDV.Tour.Script.updateVideoCues,"getRootOverlay":TDV.Tour.Script.getRootOverlay,"stopGlobalAudio":TDV.Tour.Script.stopGlobalAudio,"updateMediaLabelFromPlayList":TDV.Tour.Script.updateMediaLabelFromPlayList,"stopTextToSpeech":TDV.Tour.Script.stopTextToSpeech,"updateDeepLink":TDV.Tour.Script.updateDeepLink,"copyObjRecursively":TDV.Tour.Script.copyObjRecursively,"setMapLocation":TDV.Tour.Script.setMapLocation,"getQuizTotalObjectiveProperty":TDV.Tour.Script.getQuizTotalObjectiveProperty,"cloneCamera":TDV.Tour.Script.cloneCamera,"getPlayListItemIndexByMedia":TDV.Tour.Script.getPlayListItemIndexByMedia,"cloneBindings":TDV.Tour.Script.cloneBindings,"triggerOverlay":TDV.Tour.Script.triggerOverlay,"getPlayListItemByMedia":TDV.Tour.Script.getPlayListItemByMedia,"resumeGlobalAudios":TDV.Tour.Script.resumeGlobalAudios,"stopGlobalAudios":TDV.Tour.Script.stopGlobalAudios,"getPlayListItems":TDV.Tour.Script.getPlayListItems,"changePlayListWithSameSpot":TDV.Tour.Script.changePlayListWithSameSpot,"getKey":TDV.Tour.Script.getKey,"textToSpeechComponent":TDV.Tour.Script.textToSpeechComponent,"getFirstPlayListWithMedia":TDV.Tour.Script.getFirstPlayListWithMedia,"changeOpacityWhilePlay":TDV.Tour.Script.changeOpacityWhilePlay,"mixObject":TDV.Tour.Script.mixObject,"getPlayListWithItem":TDV.Tour.Script.getPlayListWithItem,"changeBackgroundWhilePlay":TDV.Tour.Script.changeBackgroundWhilePlay,"autotriggerAtStart":TDV.Tour.Script.autotriggerAtStart,"fixTogglePlayPauseButton":TDV.Tour.Script.fixTogglePlayPauseButton,"_getPlayListsWithViewer":TDV.Tour.Script._getPlayListsWithViewer,"quizResumeTimer":TDV.Tour.Script.quizResumeTimer,"openLink":TDV.Tour.Script.openLink,"startPanoramaWithCamera":TDV.Tour.Script.startPanoramaWithCamera,"init":TDV.Tour.Script.init,"syncPlaylists":TDV.Tour.Script.syncPlaylists,"stopAndGoCamera":TDV.Tour.Script.stopAndGoCamera,"showWindow":TDV.Tour.Script.showWindow,"resumePlayers":TDV.Tour.Script.resumePlayers,"quizPauseTimer":TDV.Tour.Script.quizPauseTimer,"getPanoramaOverlaysByTags":TDV.Tour.Script.getPanoramaOverlaysByTags,"showPopupPanoramaVideoOverlay":TDV.Tour.Script.showPopupPanoramaVideoOverlay,"showPopupPanoramaOverlay":TDV.Tour.Script.showPopupPanoramaOverlay,"quizShowQuestion":TDV.Tour.Script.quizShowQuestion,"getPanoramaOverlayByName":TDV.Tour.Script.getPanoramaOverlayByName,"showPopupImage":TDV.Tour.Script.showPopupImage,"quizSetItemFound":TDV.Tour.Script.quizSetItemFound,"getOverlaysByGroupname":TDV.Tour.Script.getOverlaysByGroupname,"showPopupMedia":TDV.Tour.Script.showPopupMedia,"showComponentsWhileMouseOver":TDV.Tour.Script.showComponentsWhileMouseOver,"getOverlaysByTags":TDV.Tour.Script.getOverlaysByTags,"shareSocial":TDV.Tour.Script.shareSocial,"playGlobalAudio":TDV.Tour.Script.playGlobalAudio,"setDirectionalPanoramaAudio":TDV.Tour.Script.setDirectionalPanoramaAudio,"playGlobalAudioWhilePlay":TDV.Tour.Script.playGlobalAudioWhilePlay,"getOverlays":TDV.Tour.Script.getOverlays,"getMediaHeight":TDV.Tour.Script.getMediaHeight,"playGlobalAudioWhilePlayActiveMedia":TDV.Tour.Script.playGlobalAudioWhilePlayActiveMedia,"skip3DTransitionOnce":TDV.Tour.Script.skip3DTransitionOnce,"setStartTimeVideo":TDV.Tour.Script.setStartTimeVideo,"playAudioList":TDV.Tour.Script.playAudioList,"setStartTimeVideoSync":TDV.Tour.Script.setStartTimeVideoSync,"pauseGlobalAudios":TDV.Tour.Script.pauseGlobalAudios,"_getObjectsByTags":TDV.Tour.Script._getObjectsByTags,"getMediaWidth":TDV.Tour.Script.getMediaWidth,"getMediaFromPlayer":TDV.Tour.Script.getMediaFromPlayer,"quizShowScore":TDV.Tour.Script.quizShowScore,"pauseGlobalAudio":TDV.Tour.Script.pauseGlobalAudio,"getComponentsByTags":TDV.Tour.Script.getComponentsByTags,"assignObjRecursively":TDV.Tour.Script.assignObjRecursively,"setPanoramaCameraWithSpot":TDV.Tour.Script.setPanoramaCameraWithSpot,"pauseCurrentPlayers":TDV.Tour.Script.pauseCurrentPlayers,"setSurfaceSelectionHotspotMode":TDV.Tour.Script.setSurfaceSelectionHotspotMode,"pauseGlobalAudiosWhilePlayItem":TDV.Tour.Script.pauseGlobalAudiosWhilePlayItem,"getMediaByTags":TDV.Tour.Script.getMediaByTags,"quizStart":TDV.Tour.Script.quizStart,"quizShowTimeout":TDV.Tour.Script.quizShowTimeout,"getMediaByName":TDV.Tour.Script.getMediaByName,"openEmbeddedPDF":TDV.Tour.Script.openEmbeddedPDF,"setPanoramaCameraWithCurrentSpot":TDV.Tour.Script.setPanoramaCameraWithCurrentSpot,"setOverlaysVisibility":TDV.Tour.Script.setOverlaysVisibility,"getMainViewer":TDV.Tour.Script.getMainViewer,"setOverlaysVisibilityByTags":TDV.Tour.Script.setOverlaysVisibilityByTags,"getGlobalAudio":TDV.Tour.Script.getGlobalAudio,"setValue":TDV.Tour.Script.setValue,"takeScreenshot":TDV.Tour.Script.takeScreenshot,"setMediaBehaviour":TDV.Tour.Script.setMediaBehaviour,"setOverlayBehaviour":TDV.Tour.Script.setOverlayBehaviour,"getCurrentPlayers":TDV.Tour.Script.getCurrentPlayers,"getCurrentPlayerWithMedia":TDV.Tour.Script.getCurrentPlayerWithMedia,"loadFromCurrentMediaPlayList":TDV.Tour.Script.loadFromCurrentMediaPlayList,"getAudioByTags":TDV.Tour.Script.getAudioByTags,"getPixels":TDV.Tour.Script.getPixels,"setMainMediaByName":TDV.Tour.Script.setMainMediaByName,"setMainMediaByIndex":TDV.Tour.Script.setMainMediaByIndex,"_initItemWithComps":TDV.Tour.Script._initItemWithComps,"setLocale":TDV.Tour.Script.setLocale,"getActivePlayerWithViewer":TDV.Tour.Script.getActivePlayerWithViewer,"quizFinish":TDV.Tour.Script.quizFinish,"keepCompVisible":TDV.Tour.Script.keepCompVisible,"_initTTSTooltips":TDV.Tour.Script._initTTSTooltips,"getActiveMediaWithViewer":TDV.Tour.Script.getActiveMediaWithViewer,"isPanorama":TDV.Tour.Script.isPanorama,"setEndToItemIndex":TDV.Tour.Script.setEndToItemIndex,"executeFunctionWhenChange":TDV.Tour.Script.executeFunctionWhenChange,"isCardboardViewMode":TDV.Tour.Script.isCardboardViewMode,"executeJS":TDV.Tour.Script.executeJS,"_initTwinsViewer":TDV.Tour.Script._initTwinsViewer,"textToSpeech":TDV.Tour.Script.textToSpeech,"setComponentVisibility":TDV.Tour.Script.setComponentVisibility,"_initSplitViewer":TDV.Tour.Script._initSplitViewer,"getComponentByName":TDV.Tour.Script.getComponentByName,"existsKey":TDV.Tour.Script.existsKey,"setCameraSameSpotAsMedia":TDV.Tour.Script.setCameraSameSpotAsMedia,"initQuiz":TDV.Tour.Script.initQuiz,"executeAudioActionByTags":TDV.Tour.Script.executeAudioActionByTags,"unregisterKey":TDV.Tour.Script.unregisterKey,"executeAudioAction":TDV.Tour.Script.executeAudioAction,"initOverlayGroupRotationOnClick":TDV.Tour.Script.initOverlayGroupRotationOnClick,"setComponentsVisibilityByTags":TDV.Tour.Script.setComponentsVisibilityByTags,"registerKey":TDV.Tour.Script.registerKey,"downloadFile":TDV.Tour.Script.downloadFile,"clone":TDV.Tour.Script.clone,"getPlayListsWithMedia":TDV.Tour.Script.getPlayListsWithMedia,"translate":TDV.Tour.Script.translate,"initAnalytics":TDV.Tour.Script.initAnalytics},"backgroundPreloadEnabled":true,"backgroundColorDirection":"vertical","width":"100%","mouseWheelEnabled":true,"toolTipHorizontalAlign":"center","backgroundColorRatios":[0],"backgroundColor":["#FFFFFF"],"layout":"absolute","contentOpaque":false,"children":["this.MainViewer"],"gap":10,"minHeight":0,"id":"rootPlayer","paddingBottom":0,"minWidth":0,"borderSize":0,"paddingTop":0,"scrollBarOpacity":0.5,"scrollBarWidth":10,"verticalAlign":"top","overflow":"hidden","downloadEnabled":false,"defaultMenu":["fullscreen","mute","rotation"],"scrollBarVisible":"rollOver","data":{"name":"Player652","locales":{"en":"locale/en.txt"},"textToSpeechConfig":{"speechOnTooltip":false,"volume":1,"speechOnQuizQuestion":false,"speechOnInfoWindow":false,"stopBackgroundAudio":false,"pitch":1,"rate":1},"defaultLocale":"en"},"shadow":false,"horizontalAlign":"left","height":"100%","borderRadius":0};
if (script['data'] == undefined)
    script['data'] = {};
script['data']['translateObjs'] = translateObjs;
script['data']['history'] = {};
script['scripts']['createQuizConfig'] = createQuizConfig;
TDV['PlayerAPI']['defineScript'](script);
//# sourceMappingURL=script_device_v2022.1.18.js.map
})();
//Generated with v2022.1.18, Sat Aug 13 2022